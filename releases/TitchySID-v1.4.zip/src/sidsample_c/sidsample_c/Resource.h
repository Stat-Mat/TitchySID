//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by sidsample_c.rc

#define IDI_ICON                        101
#define IDD_SID_PLAYER_DLG              102
#define IDR_MUSIC                       103
#define IDC_EXIT                        1001
#define IDC_INFO_LABELS                 1002
#define IDC_INFO                        1003
#define IDC_OPEN                        1004
#define IDC_NEXT                        1005
#define IDC_PREVIOUS                    1006
#define IDC_PAUSE_RESUME                1007
#define IDC_STOP                        1008
#define IDC_PLAY                        1009
#define IDC_SONG_NUM                    1010
#define IDC_SPEC                        1011
#define IDC_SUBSONG_STATIC              1012
#define IDC_INFO_STATIC                 1013

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	129
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		110
#endif
#endif
